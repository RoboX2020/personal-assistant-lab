PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS messages (
 id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, channel TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('user','assistant')), body TEXT NOT NULL,
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS messages_context ON messages(conversation_id, created_at);
CREATE TABLE IF NOT EXISTS jobs (
 id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, channel TEXT NOT NULL,
 payload TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued', attempts INTEGER NOT NULL DEFAULT 0,
 lease_until TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 result TEXT, error TEXT
);
CREATE INDEX IF NOT EXISTS jobs_due ON jobs(status, lease_until, created_at);
CREATE TABLE IF NOT EXISTS memory (
 id TEXT PRIMARY KEY, body TEXT NOT NULL, source_message_id TEXT NOT NULL,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reminders (
 id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, channel TEXT NOT NULL,
 body TEXT NOT NULL, due_at TEXT NOT NULL, timezone TEXT NOT NULL DEFAULT 'America/Phoenix',
 status TEXT NOT NULL DEFAULT 'awaiting_confirmation', attempts INTEGER NOT NULL DEFAULT 0,
 lease_until TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 sent_at TEXT, provider_message_id TEXT, error TEXT
);
CREATE INDEX IF NOT EXISTS reminders_due ON reminders(status,due_at);
CREATE TABLE IF NOT EXISTS outbox (
 id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, body TEXT NOT NULL,
 created_at TEXT NOT NULL, seen INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS usage (
 day TEXT PRIMARY KEY, model_calls INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
