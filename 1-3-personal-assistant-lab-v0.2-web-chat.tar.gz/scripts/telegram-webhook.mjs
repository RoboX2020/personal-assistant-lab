// Run locally with private environment variables. Do not paste bot tokens into URLs or chat.
const token=process.env.TELEGRAM_BOT_TOKEN,secret=process.env.TELEGRAM_WEBHOOK_SECRET,url=process.env.ASSISTANT_URL;
if(!token||!secret||!url)throw new Error('Set TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET and ASSISTANT_URL locally.');
const u=new URL(url);if(u.protocol!=='https:')throw new Error('Deployed URL must be HTTPS.');
u.pathname='/webhook/telegram';u.search='';u.hash='';
const response=await fetch(`https://api.telegram.org/bot${token}/setWebhook`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({url:u.href,secret_token:secret,allowed_updates:['message']})});
const data=await response.json();if(!response.ok||!data.ok)throw new Error('Webhook configuration failed. No token or provider details printed.');
console.log('Telegram accepted the webhook configuration. Send /help as the configured owner, then verify delivery.');
