import {spawn,spawnSync} from 'node:child_process';import {once} from 'node:events';import assert from 'node:assert/strict';import {writeFile,rm,access,mkdtemp} from 'node:fs/promises';import {chromium} from '@playwright/test';
const token='local-test-only-not-a-live-secret-0001';let server,browser;
try{await access('.dev.vars');throw new Error('Existing .dev.vars: refusing to overwrite real configuration');}catch(e){if(e.code!=='ENOENT')throw e;}
const state=await mkdtemp('/tmp/assistant-runtime-');
await writeFile('.dev.vars',`OWNER_WEB_TOKEN=${token}\nTELEGRAM_OWNER_ID=1234\nTELEGRAM_WEBHOOK_SECRET=local-webhook-test-secret\n`);
async function waitReady(){for(let i=0;i<80;i++){try{const r=await fetch('http://localhost:8787/health');if(r.ok)return;}catch{}await new Promise(r=>setTimeout(r,250));}throw new Error('Local server did not start');}
async function api(path,body,auth=token){const r=await fetch('http://localhost:8787'+path,{method:body?'POST':'GET',headers:{authorization:`Bearer ${auth}`,...(body?{'content-type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});return {status:r.status,data:await r.json()};}
async function send(text,id=crypto.randomUUID()){const r=await api('/api/messages',{text,id});assert.equal(r.status,200);return r.data;}
try{
 const schema=spawnSync('node',['node_modules/wrangler/bin/wrangler.js','d1','execute','assistant','--local','--persist-to',state,'--file=schema.sql'],{encoding:'utf8'});assert.equal(schema.status,0,schema.stderr);
 server=spawn('node',['node_modules/wrangler/bin/wrangler.js','dev','--port','8787','--test-scheduled','--persist-to',state],{stdio:['ignore','pipe','pipe']});let log='';server.stdout.on('data',x=>log+=x);server.stderr.on('data',x=>log+=x);
 await waitReady();
 assert.equal((await api('/api/status',null,'wrong')).status,401);
 const unauth=await fetch('http://localhost:8787/webhook/telegram',{method:'POST',body:'{}'});assert.equal(unauth.status,401);
 const ignored=await fetch('http://localhost:8787/webhook/telegram',{method:'POST',headers:{'x-telegram-bot-api-secret-token':'local-webhook-test-secret','content-type':'application/json'},body:JSON.stringify({update_id:7,message:{from:{id:999},chat:{id:999,type:'private'},text:'/help'}})});assert.equal((await ignored.json()).ignored,true);
 const id=crypto.randomUUID(),saved=await send('/remember The demo mascot is a fox.',id);assert.match(saved.result,/Memory saved/);
 const duplicate=await send('/remember The demo mascot is a fox.',id);assert.equal(saved.result,duplicate.result);
 const memory=JSON.parse((await send('/memory')).result);assert.equal(memory.filter(m=>m.body==='The demo mascot is a fox.').length,1);
 await send('/forget '+memory[0].id);assert.equal(JSON.parse((await send('/memory')).result).some(m=>m.id===memory[0].id),false);
 const future=new Date(Date.now()+3600000).toISOString();const preview=await send(`/remind ${future} Test reminder`);assert.match(preview.result,/not scheduled until confirmed/);
 const rid=preview.result.match(/\/confirm ([\w-]+)/)[1];let reminders=JSON.parse((await send('/reminders')).result);assert.equal(reminders.find(r=>r.id===rid).status,'awaiting_confirmation');
 assert.match((await send('/confirm '+rid)).result,/Reminder saved/);assert.match((await send('/cancel '+rid)).result,/cancelled/);
 await send('/stop');assert.match((await send('/remember blocked')).result,/stopped/);await send('/resume');
 assert.match((await send('Hello there')).result,/not a live AI response/);
 assert.match((await send('/calendar')).result,/SIMULATED CALENDAR/);
 const bad=await send('/remind tomorrow do it');assert.equal(bad.status,'failed');
 const cross=await fetch('http://localhost:8787/api/messages',{method:'POST',headers:{authorization:`Bearer ${token}`,origin:'https://untrusted.invalid','content-type':'application/json'},body:'{}'});assert.equal(cross.status,403);
 const schedule=await fetch('http://localhost:8787/__scheduled');assert.equal(schedule.status,200);
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 for(const width of [320,390,900]){
  const page=await browser.newPage({viewport:{width,height:900}});await page.goto('http://localhost:8787');await page.locator('#token').fill(token);await page.locator('#connect button').click();await page.waitForFunction(()=>document.getElementById('connection').textContent.startsWith('Connected.'));
  await page.locator('#message').fill('/status');await page.locator('#send').click();await page.waitForFunction(()=>document.querySelectorAll('#chat .bubble').length>=2);
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth);assert.equal(overflow,false,`No overflow at ${width}px`);
  await page.screenshot({path:`/downloads/assistant-ui-${width}.png`,fullPage:true});await page.close();
 }
 console.log('Runtime assertions passed: authentication, sender allowlist, idempotency, memory delete, reminder preview/confirm/cancel, stop/resume, model-free honesty, simulated calendar, invalid reminder, CSRF, scheduled dispatcher and three responsive widths.');
}finally{if(browser)await browser.close();if(server){server.kill('SIGTERM');await Promise.race([once(server,'exit'),new Promise(r=>setTimeout(r,3000))]);}await rm('.dev.vars',{force:true});await rm(state,{recursive:true,force:true});}
