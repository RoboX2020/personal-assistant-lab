import test from 'node:test';import assert from 'node:assert/strict';
import {parseCommand,parseReminder,parseRepo,privacyAllowed,splitTelegram,constantTimeEqual,publicSearchQuery} from '../src/core.js';
test('commands preserve body and parse bot suffix',()=>{assert.deepEqual(parseCommand('/remember@lab Some fact'),{name:'remember',args:'Some fact'});assert.equal(parseCommand('hello'),null);});
test('reminders require future absolute time with offset',()=>{assert.throws(()=>parseReminder('tomorrow call'));assert.throws(()=>parseReminder('2000-01-01T10:00:00Z call'));assert.throws(()=>parseReminder('2030-01-01T10:00:00 call'));assert.equal(parseReminder('2030-01-01T10:00:00-07:00 call',0).due_at,'2030-01-01T17:00:00.000Z');});
test('invalid calendar dates and offsets rejected',()=>{for(const x of ['2030-02-30T10:00:00Z call','2030-12-01T24:00:00Z call','2030-01-01T10:00:00+14:30 call'])assert.throws(()=>parseReminder(x,0));});
test('reminder body bounded',()=>assert.throws(()=>parseReminder('2030-01-01T10:00:00Z '+ 'x'.repeat(501),0)));
test('GitHub parser rejects URLs and traversal',()=>{assert.equal(parseRepo('octocat/Hello-World'),'octocat/Hello-World');for(const x of ['http://localhost','foo/../secret','foo/..','foo/bar?x=1'])assert.throws(()=>parseRepo(x));});
test('real data cannot go to unpaid or unreviewed provider',()=>{assert.equal(privacyAllowed('synthetic','unpaid'),true);assert.equal(privacyAllowed('real','unpaid'),false);assert.equal(privacyAllowed('real','paid'),false);assert.equal(privacyAllowed('real','paid-reviewed'),true);assert.equal(privacyAllowed('typo','unpaid'),false);});
test('Telegram chunks fit safe bounds',()=>{const text='x'.repeat(8000);const chunks=splitTelegram(text);assert.equal(chunks.join(''),text);assert.ok(chunks.every(x=>x.length<=3500));});
test('secret equality handles empty and mismatched length',()=>{assert.equal(constantTimeEqual('abc','abc'),true);assert.equal(constantTimeEqual('abc','abd'),false);assert.equal(constantTimeEqual('abc','ab'),false);assert.equal(constantTimeEqual(null,'abc'),false);});
test('search query bounded',()=>{assert.equal(publicSearchQuery('  public test  '),'public test');assert.throws(()=>publicSearchQuery(''));assert.throws(()=>publicSearchQuery('x'.repeat(301)));});

test('milliseconds from toISOString accepted',()=>assert.equal(parseReminder('2030-01-01T10:00:00.123Z test',0).due_at,'2030-01-01T10:00:00.123Z'));
