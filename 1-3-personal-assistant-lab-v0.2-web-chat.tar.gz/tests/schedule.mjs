import {spawn,spawnSync} from 'node:child_process';import {once} from 'node:events';import assert from 'node:assert/strict';import {writeFile,rm,access,mkdtemp} from 'node:fs/promises';
const token='local-test-only-not-a-live-secret-0002';let server;
try{await access('.dev.vars');throw new Error('Existing .dev.vars: refusing to overwrite configuration');}catch(e){if(e.code!=='ENOENT')throw e;}
const state=await mkdtemp('/tmp/assistant-schedule-');await writeFile('.dev.vars',`OWNER_WEB_TOKEN=${token}\n`);
async function api(text){const r=await fetch('http://localhost:8788/api/messages',{method:'POST',headers:{authorization:`Bearer ${token}`,'content-type':'application/json'},body:JSON.stringify({id:crypto.randomUUID(),text})});assert.equal(r.status,200);return await r.json();}
async function tick(){const r=await fetch('http://localhost:8788/__scheduled');assert.equal(r.status,200);}
async function list(){return JSON.parse((await api('/reminders')).result);}
async function schedule(body){const due=new Date(Date.now()+2000).toISOString();const d=await api(`/remind ${due} ${body}`);const id=d.result.match(/\/confirm ([\w-]+)/)[1];await api('/confirm '+id);return id;}
try {
 const schema=spawnSync('node',['node_modules/wrangler/bin/wrangler.js','d1','execute','assistant','--local','--persist-to',state,'--file=schema.sql'],{encoding:'utf8'});assert.equal(schema.status,0,schema.stderr);
 server=spawn('node',['node_modules/wrangler/bin/wrangler.js','dev','--port','8788','--test-scheduled','--persist-to',state],{stdio:['ignore','pipe','pipe']});let log='';server.stdout.on('data',d=>log+=d);server.stderr.on('data',d=>log+=d);
 let ready=false;for(let i=0;i<80;i++){try{if((await fetch('http://localhost:8788/health')).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,250));}assert.ok(ready,log);
 const id=await schedule('Due demo reminder');await new Promise(r=>setTimeout(r,2100));await tick();let rows=await list();assert.equal(rows.find(r=>r.id===id).status,'sent');
 let r=await fetch('http://localhost:8788/api/outbox',{headers:{authorization:`Bearer ${token}`}}),out=await r.json();assert.equal(out.filter(x=>x.body.startsWith('Reminder: Due demo reminder')).length,1);
 await tick();r=await fetch('http://localhost:8788/api/outbox',{headers:{authorization:`Bearer ${token}`}});out=await r.json();assert.equal(out.filter(x=>x.body.startsWith('Reminder: Due demo reminder')).length,1);
 const stopped=await schedule('Stopped demo reminder');await api('/stop');await new Promise(r=>setTimeout(r,2100));await tick();rows=await list();assert.equal(rows.find(r=>r.id===stopped).status,'pending');await api('/resume');await tick();rows=await list();assert.equal(rows.find(r=>r.id===stopped).status,'sent');
 const cancelled=await schedule('Cancelled demo reminder');await api('/cancel '+cancelled);await new Promise(r=>setTimeout(r,2100));await tick();rows=await list();assert.equal(rows.find(r=>r.id===cancelled).status,'cancelled');
 console.log('Scheduling assertions passed: due delivery, no duplicate resend, stop blocks delivery, resume recovers due reminder, cancel suppresses delivery.');
} finally {if(server){server.kill('SIGTERM');await Promise.race([once(server,'exit'),new Promise(r=>setTimeout(r,3000))]);}await rm('.dev.vars',{force:true});await rm(state,{recursive:true,force:true});}
