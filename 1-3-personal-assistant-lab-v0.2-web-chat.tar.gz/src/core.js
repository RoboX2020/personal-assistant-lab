// Public-design utilities. No application secrets or provider state here.
export const HELP = `Personal Assistant Lab (synthetic/public-data mode)
/remember <synthetic fact> - save an explicit memory
/memory - review memory
/forget <id> - delete a memory
/remind <ISO date-time with offset> <text> - preview a reminder
/confirm <id> - approve the exact reminder
/reminders | /cancel <id>
/github <owner/repo> - public repository summary
/search <public query> - sourced web search (requires a model key)
/calendar - simulated calendar only in the free demo
/tasks | /export | /delete-all CONFIRM
/stop - stop tools/reminders | /resume - resume
/status | /help
Example: /remind 2030-01-02T10:00:00-07:00 Check the prototype
No messages to other people, private integrations, payments or shell execution.`;

export function parseCommand(text) {
 const match = text.trim().match(/^\/(\w[\w-]*)(?:@\w+)?(?:\s+([\s\S]*))?$/);
 return match ? {name: match[1].toLowerCase(), args: (match[2] || '').trim()} : null;
}
export function parseReminder(args, now = Date.now()) {
 const match = args.match(/^(\S+)\s+([\s\S]+)$/);
 if (!match || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.test(match[1])) {
  throw new Error('Use /remind YYYY-MM-DDTHH:MM:SS-07:00 reminder text. Include a timezone offset.');
 }
 const due = new Date(match[1]);
 if (!Number.isFinite(due.getTime()) || due.getTime() <= now) throw new Error('The reminder time must be valid and in the future.');
 // Reject impossible dates that JavaScript would normalize, such as February 30.
 const [datePart, timePart] = match[1].split('T');
 const [year,month,day] = datePart.split('-').map(Number);
 const [hour,minute,second=0] = timePart.replace(/(Z|[+-]\d{2}:\d{2})$/, '').split(':').map(Number);
 if (month<1 || month>12 || day<1 || day>new Date(Date.UTC(year,month,0)).getUTCDate() || hour>23 || minute>59 || second>59) throw new Error('The reminder time is invalid.');
 const offset = timePart.match(/[+-](\d{2}):(\d{2})$/);
 if (offset && (Number(offset[1])>14 || Number(offset[2])>59 || (Number(offset[1])===14 && Number(offset[2])!==0))) throw new Error('The timezone offset is invalid.');
 const body = match[2].trim();
 if (body.length>500) throw new Error('Reminder text must be at most 500 characters.');
 return {due_at: due.toISOString(), body, original: match[1]};
}
export function parseRepo(value) {
 if (!/^[A-Za-z0-9][A-Za-z0-9-]{0,38}\/[A-Za-z0-9_.-]{1,100}$/.test(value) || value.endsWith('/..') || value.endsWith('/.')) throw new Error('Use a public repository as owner/repo.');
 return value;
}
export function privacyAllowed(dataMode, modelRoute) {
 return dataMode === 'synthetic' || (dataMode === 'real' && modelRoute === 'paid-reviewed');
}
export function redactError(_error) { return 'The operation failed. Check connection health; secrets and provider responses are not shown.'; }
export function splitTelegram(text) {
 const chunks=[]; let rest=text;
 while(rest.length>3500) {
  let cut=rest.lastIndexOf('\n',3500); if(cut<1500) cut=3500;
  chunks.push(rest.slice(0,cut)); rest=rest.slice(cut).replace(/^\n/,'');
 }
 if(rest) chunks.push(rest); return chunks;
}
export function constantTimeEqual(a,b) {
 if(typeof a!=='string' || typeof b!=='string') return false;
 let diff=a.length ^ b.length; for(let i=0;i<Math.max(a.length,b.length);i++) diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);
 return diff===0;
}
export function publicSearchQuery(query) {
 if(!query.trim() || query.length>300) throw new Error('Use a public search query of 1-300 characters.');
 return query.trim();
}
