# Verification report

October 10, 2026. This is a local-tested source release, not a deployed personal assistant.

## Passed

- TypeScript type check.
- 10 pure utility tests (commands, future dates, invalid calendar dates/offsets, length bounds, public repository parsing, privacy route, chunking, secret comparison and public queries).
- Clean local D1 schema application.
- Local runtime owner token check and invalid-token rejection.
- Telegram missing-secret rejection and non-owner message ignore.
- Incoming-event idempotency: duplicate memory command is processed once.
- Explicit memory save/list/delete.
- Reminder preview, exact confirmation, cancellation and invalid-date handling.
- Scheduled due reminder into web inbox, no resend on second tick.
- Stop prevents due delivery; resume recovers due delivery.
- Cancellation suppresses future delivery.
- Cross-origin authenticated POST rejected.
- Model-free response clearly identified as demo, not live AI.
- Calendar response clearly labeled simulated.
- Responsive browser render at 320px, 390px and 900px; no horizontal overflow.
- Actual 320px and 900px pixels inspected for readability, controls and caveats.
- Wrangler deployment dry-run bundles source and assets successfully.
- npm dependency audit reported zero vulnerabilities at installation time.

## Not verified

- Real Gemini inference and function calls. No real model key supplied.
- Real Google Search grounding and search-suggestions layout. Code path exists; provider response not exercised.
- Telegram owner/bot end-to-end send and receipt. No real bot token supplied.
- Remote Cloudflare deployment, account quotas, 10ms free-plan CPU compliance, uptime or cron timing.
- Official WhatsApp eligibility. Adapter is not active.
- Real calendar OAuth/private repositories. Not implemented in this release.
- Multi-user access and concurrent production load. Single-owner only.
- Automatic recovery after ambiguous external sends. Deliberately held as outcome-unknown to avoid duplicates.

## Operational caveats

No-key mode is a useful command-only demo, not an LLM chatbot. Real personal data must not be sent through the default unpaid Gemini route. A flag named paid-reviewed is only an operator attestation; it does not audit a provider or enable billing.

Reminders are best effort. A web inbox item is not a phone notification. A provider's acceptance is not proof of reading. Stop/cancel cannot recall sends already in flight. No production reliability claim follows from local tests.

Tests use temporary database state and fake local-only tokens, and refuse to overwrite existing .dev.vars. Screenshots are test data only.
