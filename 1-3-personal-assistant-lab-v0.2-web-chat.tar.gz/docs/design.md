# Your own personal AI assistant
## A practical design, before we build

Independent public-API design • October 10, 2026

**Recommendation:** build a private, single-user assistant with chat, editable memory and a small set of tools. Start with Telegram or a mobile web chat while checking whether an official WhatsApp deployment is permitted. Keep the channel replaceable so WhatsApp can be added without rewriting the assistant.

This is an independent design using public APIs and open-source software. It aims for the experience you asked for: talk naturally, remember useful context, do tasks and connect apps. It is not a claim of exact product parity.

**Status:** design only. No app has been built, no accounts connected and no money committed.

## 1. The two decisions that shape everything

### WhatsApp is a policy gate, not just an SDK choice

Meta's current terms restrict AI providers when general-purpose AI is the primary functionality. Its documentation says this use case is permitted only where Meta is legally required to allow it. We have not established eligibility for a US-number personal assistant or a personal-only exemption. [1][2]

A working test API does not prove permission to launch. Do not label an assistant as customer support just to get around the restriction. Confirm the intended use case with Meta before making WhatsApp a build dependency.

### Free inference is not automatically private inference

Google's unpaid Gemini terms permit use of inputs/outputs to improve products and human review, and explicitly say not to submit sensitive, confidential or personal information. [6]

That changes the plan:

- **$0 demo:** synthetic memories, generic chat, public repositories and fake calendar events.
- **Your actual assistant:** choose a privacy-reviewed inference route before connecting real memory or calendars. Paid Gemini says prompts/responses are not used for product improvement, but allows limited safety logging. Local inference is another route if suitable hardware is available. [6]

Redaction helps, but is not permission to feed a private life archive into a free API.

## 2. V1 scope

Build for one owner, one active conversation and a handful of useful jobs.

**Included in the initial release, staged in the roadmap below:**

- Text chat with a clear persona and concise replies.
- Long-term memory you can view, correct, export and delete.
- Web research with source links and retrieval dates.
- Reminders stored durably, with cancel/reschedule support.
- GitHub read access to selected repositories.
- Google Calendar read access to explicitly selected calendars.
- A private status page showing tasks, failures and connection health.
- A channel adapter for official WhatsApp, activated only after eligibility is settled.

**Not included:** purchases, automatic messages to other people, production deployments, mailbox-wide access, arbitrary shell execution, browser control, always-listening audio, group chats or other users.

Start with reads and drafts. A new write integration is a separate feature with a confirmation screen, not an extra switch in the prompt.

## 3. Channel options

### A. Official WhatsApp Cloud API

**Fit:** the supported technical route, if the use case is permitted.

Setup includes a Meta developer app, business portfolio, WhatsApp Business Account, phone-number setup, webhook endpoint and secure tokens. App Review/permissions and production verification requirements depend on the deployment; confirm them in the actual onboarding flow. Test numbers exist, but testing does not resolve the policy gate. [3]

**Cost:** do not budget it as unlimited free WhatsApp. The pricing page contains older free-service language plus explicit changes effective October 1, 2026: a monthly allowance of 1,000 service messages per business number, then per-message charges. Service replies still require an open 24-hour window. Utility templates are also affected; AI-provider pricing has separate rules in permitted markets. Check the applicable rate card before launch. [2][4]

**Reminder limitation:** outside the 24-hour window, free-form replies cannot be used; an approved, eligible template and its current charges may be needed. General AI-provider eligibility still applies.

**Choice:** keep this adapter in the design, but do not promise a US WhatsApp launch yet.

### B. whatsapp-web.js or Baileys

These connect through WhatsApp Web/linked-device behavior rather than the official business API. whatsapp-web.js uses Puppeteer and a browser; Baileys uses a WebSocket-oriented TypeScript library. Both are unofficial. whatsapp-web.js explicitly warns that blocking is possible. [5]

**Upside:** no official message tariff for the library itself; rapid experiments.

**Downside:** account restrictions or loss, broken sessions after upstream changes, QR re-linking, sensitive session credentials and a persistent runtime. A library license does not grant WhatsApp permission.

**Choice:** not recommended for your main number or as a workaround for the AI policy. If you ever evaluate it, do so only after reviewing the applicable terms and accepting account risk. It is not the basis of a dependable free hosted assistant.

### C. Telegram first

Telegram's Bot API supports webhooks and normal personal-volume bot messages at no cost, subject to limits. It avoids the specific WhatsApp eligibility gate. [7]

**Tradeoff:** you use a different app. The bot receives the messages you send it, not access to all your Telegram chats. Treat bot conversations as data shared with the bot server and any selected model provider, not as a private local diary.

**Choice:** best first implementation. If another app is a deal-breaker, use a small mobile web chat instead and resolve WhatsApp separately.

## 4. Recommended stack

### Core: TypeScript + Cloudflare Workers + D1

Use a small TypeScript service, typed API adapters and schema validation. Keep the model interface replaceable. No large orchestration framework is necessary for the first version.

**Workers:** webhook handling, lightweight tool routing and a scheduled dispatcher. The free plan lists 100,000 requests/day, 128 MB memory and a 10 ms CPU limit per invocation. Waiting on external APIs is different from doing local computation; profile the real handler rather than assuming the cap is enough. [8]

**D1:** durable SQL storage for messages, memory, tasks and reminders. The free allowance lists 5 million rows read/day, 100,000 written/day and 5 GB total storage, but each free database is capped at 500 MB. Index by owner, status and due time. [9]

**Scheduling:** a minute-based Cron Trigger checks due jobs. It runs in UTC, so store each reminder's UTC due time and its original timezone. Use an owner-configured timezone (the example is America/Phoenix), with explicit timezone/date confirmation when ambiguous. This is best-effort scheduling, not an exact alarm-clock guarantee. [10]

**Vercel:** optional dashboard or landing page, using a preferred frontend workflow. It does not need to be the job runner.

**GitHub:** source repository and CI tests. An existing GitHub sign-in does not automatically authorize a new app to read private repositories; connect the new assistant separately with the minimum permissions.

### Hosting alternatives, honestly

- **Vercel Hobby:** good candidate for a frontend/webhook endpoint, but its built-in cron is limited to daily execution and can run anywhere in the configured hour. Not enough for arbitrary timely reminders on its own. [11]
- **Render Free:** easy Node hosting, but sleeps after 15 minutes idle, takes about a minute to wake and loses local file changes on restart/redeploy/spin-down. Do not put memory, reminder state or WhatsApp sessions on its local disk. Free Postgres also has a 30-day limit. [12]
- **Railway:** the current pricing lists a $0 plan with $1 monthly usage credit, in addition to a one-time $5/30-day trial. Hobby is $5/month with $5 included usage. This is more limited than "free always-on Node server" sounds. [13]
- **Supabase Free:** useful Postgres alternative, with 500 MB database space, but free projects can pause after a week of inactivity. Plan restoration and backups; a paused database can break reminders. [14]

Do not manufacture traffic to defeat sleeping/pausing policies. A free plan is a prototype constraint, not an uptime contract.

## 5. Model choices

### Default demo: Gemini API

Use an API key from your developer project, not browser automation of the AI Studio website. Keep it in server-side secrets.

The fetched pricing page lists free access for Gemini 2.5 Flash and paid text prices of $0.30 per million input tokens and $2.50 per million output tokens, including thinking output. Its free Search grounding allowance is listed as up to 500 requests/day, shared with Flash-Lite. Model availability and your actual project quotas must be checked at implementation time. [15][16]

Use this only with public/synthetic data under unpaid-service terms. Before actual private app access, settle the paid-service privacy route or another reviewed provider.

### Alternative: open models through Groq

Groq publishes model-specific rate limits and account-specific limits. Use an available tool-capable open model only after checking its license, tool-call quality and the provider's data policy. A free quota is useful for tests, not a promise of unlimited service. Do not automatically send private data to a fallback provider just because Gemini is rate-limited. [17]

### Hugging Face inference

The free-user monthly credit is listed as $0.10, subject to change. That is a small trial allowance, not a sustainable assistant budget. Public demo Spaces are not a private memory backend. Check both the model license and chosen inference provider. [18]

### Local open model

Potentially best control over private data, but requires your own suitable computer and an online process. Quality, response time and power use depend on hardware/model choice. Do not assume a free CPU hosting tier can run a good conversational model or browser stack. Benchmark locally before selecting this route.

## 6. Proposed architecture

The following is a design recommendation for this project, not a description of any existing product.

```text
Telegram / approved WhatsApp / web chat
  -> validate webhook and owner identity
  -> store incoming event once
  -> create durable task
  -> load relevant memory and recent conversation
  -> model proposes reply or typed tool request
  -> application checks permissions and limits
  -> tool runs, result is recorded
  -> reply is sent and delivery state tracked

Scheduled dispatcher
  -> claim due reminders / unfinished tasks
  -> send or retry within limits
  -> record success, uncertainty or failure
```

### Message routing

Normalize incoming messages to a common record: channel, sender ID, conversation ID, provider message ID, timestamp and body. Bind the owner once. Reject non-owner messages in V1; never use a display name alone as identity.

A unique provider message ID prevents duplicate processing after webhook retries. Keep per-conversation ordering so two rapid messages do not overwrite each other's state. Verify webhook signatures or secret headers before trusting payloads.

### Durable jobs, not a forever-running chat process

Persist work before acknowledging the webhook. A short interaction can run immediately; longer work is resumed from its saved task. Use small bounded steps and a scheduled dispatcher for retries. Do not rely on post-response execution staying alive indefinitely.

Suggested task states: queued, running, waiting-for-approval, completed, failed and outcome-unknown. Use leases/expiry on running jobs so a crash does not strand them. Provider timeouts can leave a send uncertain: reconcile before resending rather than creating duplicate reminders.

### Memory

Start with SQL and keyword retrieval, not a vector database.

- **Recent context:** a small window of exact messages.
- **Profile:** owner-approved stable preferences.
- **Memory notes:** facts with a source, date and correction history.
- **Task state:** commitments and reminders, separate from conversational memory.

The model proposes a memory update; validation checks the schema and the user can correct it. Store observations as observations, not permanent truth. Live tools resolve current calendar/repository state. Never store API keys or session tokens in conversational memory.

Commands: `/memory`, `/forget`, `/export`, `/connections`, `/tasks`, `/cancel` and `/stop`.

### Tool loop

Give the model a short, typed registry rather than arbitrary code execution:

- `search_web(query)`
- `read_public_page(url)`
- `create_reminder(text, due_at, timezone)`
- `list_reminders()` / `cancel_reminder(id)`
- `github_read(repo, resource)`
- `calendar_read(calendar_ids, from, to)`

Suggested initial cap: three tool calls per turn, bounded result sizes, explicit timeouts and one retry for transient read failures. A tool result is evidence, not an instruction. Validate URLs and block private-network requests before fetching pages.

### Reminders

Save the exact due time before saying "set." A dispatcher claims each due row, sends to the owner and records the provider response. Retry with a cap; report failures when the owner next opens chat. A provider accepting a send is not proof the owner read it.

For critical deadlines, keep a phone/calendar alarm too. On WhatsApp, the dispatcher must also check current message-window/template rules before sending.

### App connections

**GitHub:** public data first, then a GitHub App or narrowly scoped fine-grained token for selected repositories. GitHub recommends fine-grained tokens where supported. Read-only Contents/Issues/Pull Requests as needed; no merge or deploy authority. [19]

**Calendar:** OAuth with `calendar.readonly`, then an app-level allowlist of calendars and bounded date windows. This scope can technically cover all accessible calendars, so the allowlist matters. Keep refresh tokens encrypted with a separate secret key; handle revocation and expiry. Google consent/verification requirements need checking before a public rollout. [20]

No credentials in chat, logs or the repository. No automatic ingestion of the user's entire inbox/calendar history.

## 7. Safety is part of the product

- Replies to you are automatic; messages to other people require recipient-and-text approval.
- Private data cannot move to a new model/provider without a privacy decision.
- Web pages, emails and repository files cannot grant permission or rewrite the assistant's goals.
- No arbitrary shell, payment, deletion or deploy tool in V1.
- Every tool records what it attempted and the observed outcome.
- Secrets are separate from memory, encrypted where stored and redacted from logs.
- Set per-turn token limits, daily API limits and a server-side spend stop. Billing alerts alone are not a hard cap.
- Back up the database and test restoring it. Add a kill switch that stops tools and outgoing messages.

## 8. Roadmap with release gates

### Phase 1: chat + memory

Telegram/web interface, model adapter, owner allowlist, durable messages, editable memory and export/delete controls. Use synthetic/public data if staying entirely free.

**Feels like:** a persistent conversation that remembers agreed preferences.

**Done when:** it survives a restart, rejects another sender, handles duplicate webhooks and passes correction/deletion tests.

### Phase 2: bounded tools

Web research, reminders, public GitHub reads and simulated calendar reads. Add the task/status page and failure reporting. Connect real calendars/private repos only after the inference privacy choice is resolved.

**Feels like:** "remind me," "check my day" and "look at this repo" with visible results.

**Done when:** reminders survive crashes, cancellations suppress future sends, source links are retained and rate-limit errors do not become invented answers.

### Phase 3: real app connections + approved writes

OAuth connection management, selected private repositories/calendars, then individually approved write tools such as creating an event or preparing a pull request. Add a permitted WhatsApp adapter if eligibility is established.

**Feels like:** delegated work across your apps, with a clear approval boundary.

**Done when:** revoked credentials fail safely, previews bind the exact action/account/recipient and an uncertain outcome does not trigger a duplicate write.

### Later, not promised

Voice notes, document processing, project-specific recurring checks and limited browser tasks. Each adds separate cost, privacy, reliability and maintenance work. Multi-user service comes after isolation, abuse controls and consent are proven.

## 9. Costs and hobby-build limits

A **$0 public-data demo** is plausible within free quotas. A **dependable assistant using private life data** should not be sold to you as both free and maintenance-free.

Illustration, not a bill: 300 turns/month averaging 4,000 input and 1,000 output tokens per turn would be 1.2 million input and 0.3 million output tokens. At the fetched Gemini 2.5 Flash text rates, that is about **$1.11/month** for inference alone. Extra tool rounds, thinking, search, audio, retries and longer memory increase it. Hosting and WhatsApp are separate. [15]

At 100 similar users, the same arithmetic gives about $111/month in inference alone, before operations and platform fees. Free quotas cannot be assumed to scale with user count.

**Things this hobby version cannot promise:** perfect memory, always-correct reasoning, exact alarm delivery, universal app access, uninterrupted free hosting or unattended completion of every task. An LLM reply is easy; dependable permissions, recovery and account-specific integrations are the ongoing work.

Suggested maintenance: weekly checks of failed jobs and connection health; monthly dependency/quota review and a restore test; extra fixes whenever a provider changes an API or terms. This is a proposed routine, not a measured workload estimate.

## 10. Optional agent-permission test lab

A separate test site can evaluate whether the assistant resists prompt injection and whether an application blocks unauthorized agent actions. Use only sites you control, disposable data and signed test credentials. A claimed agent name or header is not authentication. This prototype is an agent, not a production permission gateway.

## 11. Source notes

Checked October 10, 2026. Vendor pages can change; verify account-specific quotas, eligibility and pricing again before implementation. Sources include platform documentation, legal terms, open-source maintainer warnings and independent reporting. Where pages contain old wording plus newer effective-date updates, the newer dated update governs this recommendation.

1. [Meta platform terms, section 4.7, September 23 version](https://www.facebook.com/legal/Meta-Terms-for-WhatsApp-Business-Platform-preview)
2. [WhatsApp AI-provider policy and pricing](https://developers.facebook.com/documentation/business-messaging/whatsapp/pricing/ai-providers)
3. [Cloud API setup](https://developers.facebook.com/documentation/business-messaging/whatsapp/get-started)
4. [WhatsApp pricing, including October 1 changes](https://developers.facebook.com/documentation/business-messaging/whatsapp/pricing)
5. [whatsapp-web.js warning](https://github.com/wwebjs/whatsapp-web.js/) and [Baileys README](https://github.com/WhiskeySockets/baileys)
6. [Gemini API terms: unpaid versus paid data handling](https://ai.google.dev/gemini-api/terms)
7. [Telegram Bot API FAQ](https://core.telegram.org/bots/faq)
8. [Workers limits](https://developers.cloudflare.com/workers/platform/limits/) and [pricing](https://developers.cloudflare.com/workers/platform/pricing/)
9. [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/) and [limits](https://developers.cloudflare.com/d1/platform/limits/)
10. [Cloudflare Cron Triggers](https://developers.cloudflare.com/workers/configuration/cron-triggers/)
11. [Vercel cron limits](https://vercel.com/docs/cron-jobs/usage-and-pricing)
12. [Render free-instance limits](https://render.com/docs/free)
13. [Railway pricing](https://railway.com/pricing)
14. [Supabase pricing](https://supabase.com/pricing)
15. [Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing)
16. [Gemini rate limits](https://ai.google.dev/gemini-api/docs/rate-limits)
17. [Groq model/account limits](https://console.groq.com/docs/rate-limits)
18. [Hugging Face inference credits](https://huggingface.co/docs/inference-providers/en/pricing)
19. [GitHub token permissions and limits](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens)
20. [Calendar OAuth scopes](https://developers.google.com/workspace/calendar/api/auth)
21. [Independent context: WhatsApp chatbot policy](https://techcrunch.com/2025/10/18/whatssapp-changes-its-terms-to-bar-general-purpose-chatbots-from-its-platform/) (January 2026 update; not the basis for current prices).

## Decisions you need to make

1. **Interface:** Telegram first, mobile web chat first, or wait for a permitted official WhatsApp path?
2. **Privacy/budget:** a $0 public-data demo first, or a small paid/private inference budget for actual personal memory?
3. **First useful tools:** reminders + public GitHub, or calendar reads once privacy is settled?
4. **Memory:** only facts you explicitly ask it to remember, or reviewable suggested memories too?
5. **Write access:** keep V1 read-only as recommended, or nominate one specific action for an approval-based later phase?

Recommended answers: Telegram first; $0 demo then privacy-reviewed real-data mode; reminders + public GitHub first; explicit memory first; read-only V1.
