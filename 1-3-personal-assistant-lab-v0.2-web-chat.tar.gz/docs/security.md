# Threat model and controls

Single owner, trusted operator, untrusted incoming network traffic and untrusted model/tool content.

## Boundaries

- Owner identified by Telegram numeric ID or a long bearer token. Display names are not identities.
- Webhook secret checked before message ingestion; group/non-owner traffic ignored.
- Web API has no permissive CORS; same-origin POST check plus bearer authentication.
- Browser token kept in tab memory. No localStorage, sessionStorage or analytics.
- Message text inserted using textContent. Search markup isolated in a sandboxed frame with scripts disabled. Actual provider suggestions need live visual verification.
- Source contains no real credentials. Provider keys are passed in request headers rather than model URLs.
- Default free inference limited to synthetic/public data by policy and operator configuration. The software cannot reliably detect whether a human typed personal data; UI warnings and access policy remain necessary.
- Model tool registry contains only public GitHub read and memory read. Commands separately gate explicit memory/reminder changes. No arbitrary URL fetch, code execution, private repository credentials or purchases.
- Unique message IDs, database claims and state transitions prevent routine duplicate execution.
- In-flight failures become outcome-unknown, not automatic repeated sends.

## Limits to address before a public service

- Production rate limiting and stronger owner login/session handling.
- Model-output adversarial testing, secret-scanning CI and dependency update process.
- Real OAuth token encryption/rotation, consent, connection revocation and scoped connector tests.
- Per-owner database isolation and multi-user tenancy (currently absent).
- Full data export/backups/deletion retention policy across service providers.
- Provider-safe Google Search suggestions presentation across channels.
- Remote CPU/latency and failure behavior under free hosting limits.

This is not a security audit. Do not expose real private data until these deployment-specific controls have been reviewed.
